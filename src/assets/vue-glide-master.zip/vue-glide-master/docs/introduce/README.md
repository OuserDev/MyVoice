# Introduce

**vue-glide-js** - Just simple vue component on top of the Glide.js.

The goal of the project is fast integration glide.js in projects on vue. Also it is simple to raise the development experience on Vue.

Copyright © 2018-present, [Anton Reshetov]('https://github.com/antonreshetov'). Licensed under the terms of the MIT License.
